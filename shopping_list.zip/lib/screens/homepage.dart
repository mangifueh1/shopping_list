// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shopping_list/models/list_model.dart';

import '../widgets/nav_bar.dart';
import '../widgets/search_bar.dart';
import '../widgets/shopping_list_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int randomValue({int max = 4}) {
    return Random().nextInt(max);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(
              image: AssetImage('assets/logo.png'),
              fit: BoxFit.cover,
              height: 40,
            ),
            SizedBox(width: 10),
            Text(
              'Shopify',
              style: GoogleFonts.cairo(
                fontSize: 48,
                color: Colors.black,
              ),
            ),
          ],
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SearchBar(),
                Expanded(
                  child: listModels.isEmpty
                      ? Center(
                          child: Text(
                            'No Shopping List To Show',
                            style: GoogleFonts.montserrat(
                              fontSize: 15,
                              color: Colors.grey,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        )
                      : GridView.builder(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 7,
                            mainAxisSpacing: 5,
                            mainAxisExtent: 270,
                          ),
                          itemCount: listModels.length,
                          itemBuilder: (context, index) {
                            return ListCard(
                              number: index,
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
          NavBar(),
        ],
      ),
    );
  }
}
