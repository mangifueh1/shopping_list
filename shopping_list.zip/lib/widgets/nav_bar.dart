// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class NavBar extends StatelessWidget {
  const NavBar({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        height: 91,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 246, 220),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(36, 158, 158, 158),
              offset: Offset(0, -5),
              blurRadius: 5,
              spreadRadius: 3,
            ),
          ],
        ),
        child: GNav(
          rippleColor: Colors.transparent,
          hoverColor: Colors.transparent,
          haptic: true, // haptic feedback
          tabBorderRadius: 25,
          tabActiveBorder: Border.all(color: Colors.black12),
          curve: Curves.easeOutExpo,
          duration: Duration(
            milliseconds: 400,
          ),
          // tab animation duration
          gap: 8,
          color: Color.fromARGB(197, 66, 66, 66),
          activeColor: Color.fromARGB(255, 241, 185, 0),
          iconSize: 35,
          tabBackgroundColor: Color(0xFFFDC602).withOpacity(0.1),
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
          tabs: [
            GButton(
              icon: Icons.home,
              text: 'Home',
            ),
            GButton(
              icon: Icons.note_add_rounded,
              text: 'Lists',
            ),
            GButton(
              icon: Icons.settings,
              text: 'Settings',
            )
          ],
          
        ),
      ),
    );
  }
}
