// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class SearchBar extends StatefulWidget {
  const SearchBar({
    Key? key,
  }) : super(key: key);

  @override
  State<SearchBar> createState() => _SearchBarState();
}

class _SearchBarState extends State<SearchBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 41,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Color(0xffffc42e).withOpacity(0.12),
        borderRadius: BorderRadius.circular(25),
      ),
      child: TextFormField(
        decoration: InputDecoration(
          hintText: 'Search for shopping list',
          hintStyle: GoogleFonts.inter(
            color: Color(0xff959494),
            textStyle: TextStyle(
              fontSize: 14,
            ),
          ),
          contentPadding: EdgeInsets.only(left: 20, bottom: 10),
          border: InputBorder.none,
        ),
      ),
    );
  }
}

