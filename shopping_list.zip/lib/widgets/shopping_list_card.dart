// ignore_for_file: prefer_const_constructors

import 'dart:math';

import 'package:flutter/material.dart';

class ListCard extends StatefulWidget {
  const ListCard({Key? key, required this.number}) : super(key: key);

  final int number;

  @override
  State<ListCard> createState() => _ListCardState();
}

class _ListCardState extends State<ListCard> {
  // late Color _color;

  @override
  void initState() {
    super.initState();
  }
  Color randomColor(int vcolor) {
    return Color(0xFFFFFFFF & Random().nextInt(0xFFFFFFFF) * vcolor)
        .withOpacity(0.12);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 30),
      // height: 241,
      width: 187,
      decoration: BoxDecoration(
        color: randomColor(widget.number), //Color(0xffC83939).withOpacity(0.12)
        borderRadius: BorderRadius.circular(25),
      ),
    );
  }
}
