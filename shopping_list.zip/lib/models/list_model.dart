// ignore_for_file: prefer_const_constructors

class ListModel {
  final String name;
  final String ingridients;

  const ListModel({required this.name, required this.ingridients});
}

List listModels = [
  ListModel(name: 'name', ingridients: 'ingridients'),
  ListModel(name: 'name', ingridients: 'ingridients'),
  ListModel(name: 'name', ingridients: 'ingridients'),

];
